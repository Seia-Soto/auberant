exports.run = (client, message, args) => {
  
}

exports.conf = {
  enabled: true,
  guildOnly: true,
  aliases: ['docs'],
  permLevel: 0
}

exports.help = {
  name: 'help',
  description: 'How to use',
  usage: 'help'
}
