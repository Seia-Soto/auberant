module.exports = client => {
  console.log(`Reconnecting at ${new Date()}`);
};
